# CLA-76 Stereo Tribute (work in progress)

Original FET-style stereo compressor, inspired by classic FET compression. Not affiliated with any commercial product.

## Status
- Stage 1-2 DONE: project layout, JUCE-free DSP (`Source/CompressorDSP.*`), 11-test validation (`Tests/DspTests.cpp`) - compiled and passing.
- JUCE processor + parameters written but NOT yet compiled against JUCE (no JUCE/network in authoring environment).
- Stage 3 (skinned editor, knobs, VU meter), full README and Studio One guide: next.

## Build
DSP tests only (no JUCE):  `cmake -B build -DCLA_BUILD_PLUGIN=OFF && cmake --build build && ./build/cla_dsp_tests`
Plugin: `cmake -B build && cmake --build build --config Release` (fetches JUCE 8.0.4; VST3 copied to your VST3 folder).
