#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "CompressorDSP.h"

namespace ids
{
inline constexpr const char* input = "input", *output = "output", *attack = "attack", *release = "release",
    *ratio = "ratio", *meter = "meter", *compOff = "compOff", *analog = "analog", *revision = "revision",
    *humLevel = "humLevel";
}

class CLA76Processor : public juce::AudioProcessor
{
public:
    CLA76Processor();
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "CLA-76 Stereo Tribute"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    const cla::CompressorDSP& getDsp() const { return dsp; }   // UI reads real DSP meter values
    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    cla::CompressorDSP dsp;
    std::atomic<float> *pIn, *pOut, *pAtk, *pRel, *pRatio, *pCompOff, *pAnalog, *pRev, *pHum;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (CLA76Processor)
};
