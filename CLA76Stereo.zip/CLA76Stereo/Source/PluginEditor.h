#pragma once
#include "PluginProcessor.h"
// STAGE 3 PLACEHOLDER: generic parameter UI. The skinned CLA-76 editor replaces this next.
class CLA76Editor : public juce::GenericAudioProcessorEditor
{
public:
    explicit CLA76Editor (CLA76Processor& p) : juce::GenericAudioProcessorEditor (p) { setSize (420, 420); }
};
