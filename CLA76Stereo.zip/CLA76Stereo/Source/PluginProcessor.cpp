#include "PluginProcessor.h"
#include "PluginEditor.h"
using namespace juce;

AudioProcessorValueTreeState::ParameterLayout CLA76Processor::createLayout()
{
    std::vector<std::unique_ptr<RangedAudioParameter>> p;
    auto dB = [] (float v) { return String (v, 1) + " dB"; };
    auto rng = [] (float lo, float hi, float centre) { NormalisableRange<float> r (lo, hi); r.setSkewForCentre (centre); return r; };

    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { ids::input, 1 }, "Input", NormalisableRange<float> (0.f, 48.f, 0.1f), 18.f,
                 AudioParameterFloatAttributes().withStringFromValueFunction ([=] (float v, int) { return dB (v); })));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { ids::output, 1 }, "Output", NormalisableRange<float> (-24.f, 24.f, 0.1f), -14.f,
                 AudioParameterFloatAttributes().withStringFromValueFunction ([=] (float v, int) { return dB (v); })));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { ids::attack, 1 }, "Attack", rng (0.02f, 0.8f, 0.1265f), 0.2f,
                 AudioParameterFloatAttributes().withStringFromValueFunction ([] (float v, int) { return String (v, 3) + " ms"; })));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { ids::release, 1 }, "Release", rng (50.f, 1100.f, 234.5f), 250.f,
                 AudioParameterFloatAttributes().withStringFromValueFunction ([] (float v, int) { return String (roundToInt (v)) + " ms"; })));
    p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { ids::ratio, 1 }, "Ratio", StringArray { "4:1", "8:1", "12:1", "20:1", "ALL" }, 0));
    p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { ids::meter, 1 }, "Meter", StringArray { "GR", "IN", "OUT" }, 0));
    p.push_back (std::make_unique<AudioParameterBool>   (ParameterID { ids::compOff, 1 }, "Comp Off", false));
    p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { ids::analog, 1 }, "Analog", StringArray { "50 Hz", "60 Hz", "OFF" }, 2));
    p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { ids::revision, 1 }, "Revision", StringArray { "BLUEY", "BLACKY" }, 0));
    p.push_back (std::make_unique<AudioParameterFloat>  (ParameterID { ids::humLevel, 1 }, "Hum Level", NormalisableRange<float> (-100.f, -60.f, 0.1f), -84.f));
    return { p.begin(), p.end() };
}

CLA76Processor::CLA76Processor()
    : AudioProcessor (BusesProperties().withInput ("Input", AudioChannelSet::stereo(), true)
                                       .withOutput ("Output", AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    pIn = apvts.getRawParameterValue (ids::input);   pOut = apvts.getRawParameterValue (ids::output);
    pAtk = apvts.getRawParameterValue (ids::attack); pRel = apvts.getRawParameterValue (ids::release);
    pRatio = apvts.getRawParameterValue (ids::ratio); pCompOff = apvts.getRawParameterValue (ids::compOff);
    pAnalog = apvts.getRawParameterValue (ids::analog); pRev = apvts.getRawParameterValue (ids::revision);
    pHum = apvts.getRawParameterValue (ids::humLevel);
}

void CLA76Processor::prepareToPlay (double sr, int) { dsp.prepare (sr); }

bool CLA76Processor::isBusesLayoutSupported (const BusesLayout& l) const
{
    return l.getMainOutputChannelSet() == AudioChannelSet::stereo() && l.getMainInputChannelSet() == AudioChannelSet::stereo();
}

void CLA76Processor::processBlock (AudioBuffer<float>& buf, MidiBuffer&)
{
    ScopedNoDenormals noDenormals;
    cla::Params p;
    p.inputDb = pIn->load(); p.outputDb = pOut->load(); p.attackMs = pAtk->load(); p.releaseMs = pRel->load();
    p.ratio = (cla::Ratio) (int) pRatio->load();
    p.revision = (cla::Revision) (int) pRev->load();
    const int a = (int) pAnalog->load();                       // 0 = 50 Hz, 1 = 60 Hz, 2 = OFF
    p.hum = a == 0 ? cla::HumMode::Hz50 : a == 1 ? cla::HumMode::Hz60 : cla::HumMode::Off;
    p.humLevelDb = pHum->load();
    p.compEnabled = pCompOff->load() < 0.5f;
    dsp.setParams (p);
    dsp.process (buf.getArrayOfWritePointers(), jmin (2, buf.getNumChannels()), buf.getNumSamples());
}

AudioProcessorEditor* CLA76Processor::createEditor() { return new CLA76Editor (*this); }

void CLA76Processor::getStateInformation (MemoryBlock& d)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, d);
}
void CLA76Processor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType())) apvts.replaceState (ValueTree::fromXml (*xml));
}

AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new CLA76Processor(); }
