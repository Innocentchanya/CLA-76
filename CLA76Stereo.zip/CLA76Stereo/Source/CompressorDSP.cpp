#include "CompressorDSP.h"
#include <algorithm>

namespace cla
{
namespace
{
constexpr double kThresholdDb = -6.0;            // fixed threshold: input knob drives the signal into it
constexpr double kLn10Over20  = 0.11512925464970229;
inline double dbToLin (double d) { return std::exp (d * kLn10Over20); }
inline double coefFromMs (double ms, double fs) { return std::exp (-1.0 / (std::max (ms, 1e-4) * 0.001 * fs)); }
inline void snap (double& v, double t) { if (std::fabs (v - t) < 1e-9) v = t; }   // also kills denormal tails
inline double ratioValue (Ratio r)
{
    switch (r) { case Ratio::R4: return 4; case Ratio::R8: return 8; case Ratio::R12: return 12; default: return 20; }
}
}

void CompressorDSP::prepare (double sampleRate)
{
    fs = sampleRate;
    smoothC = coefFromMs (20.0, fs);   // gain smoothing (zipper-free)
    mixC    = coefFromMs (10.0, fs);   // comp on/off crossfade
    humC    = coefFromMs (30.0, fs);   // hum fade in/out
    vuA     = 1.0 - coefFromMs (65.0, fs); // VU-style averaging (~300 ms to 99%)
    reset();
}

void CompressorDSP::reset()
{
    gr = inMs = outMs = humPhase = 0;
    snapNext = true;
    grDb = 0.f; inDb = -120.f; outDb = -120.f;
}

void CompressorDSP::setParams (const Params& np)
{
    p = np;
    // REVISION voicing (original approximations, NOT claimed hardware-exact):
    //  BLUEY : attack x1.0, release x1.0, 6 dB knee, slightly asymmetric saturation (adds even harmonics)
    //  BLACKY: attack x0.85, release x0.8 (quicker recovery), 4 dB knee, symmetric, slightly harder saturation
    const bool bluey = p.revision == Revision::Bluey;
    aC = coefFromMs (p.attackMs  * (bluey ? 1.0 : 0.85), fs);
    rC = coefFromMs (p.releaseMs * (bluey ? 1.0 : 0.80), fs);
    if (snapNext)
    {
        inG  = dbToLin (p.inputDb);
        outG = dbToLin (p.outputDb);
        mix  = p.compEnabled ? 1.0 : 0.0;
        humG = p.hum == HumMode::Off ? 0.0 : dbToLin (p.humLevelDb);
        snapNext = false;
    }
}

double CompressorDSP::gainReductionDb (double lvl, Ratio r, Revision rev)
{
    // ALL mode (all ratio buttons in): lower effective threshold, hard knee and a slope that
    // climbs with overshoot (~12:1 near threshold toward ~100:1) - artistic emulation of the
    // aggressive, nonlinear "all buttons" behaviour, not a circuit model.
    const bool all   = r == Ratio::All;
    const double thr = kThresholdDb + (all ? -4.0 : 0.0);
    const double knee = all ? 2.0 : (rev == Revision::Bluey ? 6.0 : 4.0);
    const double over = lvl - thr;
    if (2.0 * over < -knee) return 0.0;
    const double slope = all ? 0.90 + 0.09 * (1.0 - std::exp (-std::max (over, 0.0) / 10.0))
                             : 1.0 - 1.0 / ratioValue (r);
    if (2.0 * over <= knee) { const double t = over + 0.5 * knee; return slope * t * t / (2.0 * knee); }
    return slope * over;
}

void CompressorDSP::process (float* const* ch, int nCh, int n)
{
    if (nCh < 1 || n <= 0) return;
    float* L = ch[0];
    float* R = nCh > 1 ? ch[1] : nullptr;

    const double inT  = dbToLin (p.inputDb), outT = dbToLin (p.outputDb);
    const double mixT = p.compEnabled ? 1.0 : 0.0;
    const double humT = p.hum == HumMode::Off ? 0.0 : dbToLin (p.humLevelDb);
    const double humW = 6.283185307179586 * (p.hum == HumMode::Hz50 ? 50.0 : 60.0) / fs;
    const bool bluey  = p.revision == Revision::Bluey;
    const double satD = bluey ? 0.8 : 1.0;
    const double satB = bluey ? 0.06 : 0.0;
    const double satOff = std::tanh (satD * satB);
    const Ratio ratio = p.ratio;
    const Revision rev = p.revision;

    for (int i = 0; i < n; ++i)
    {
        inG  = inT  + (inG  - inT)  * smoothC; snap (inG, inT);
        outG = outT + (outG - outT) * smoothC; snap (outG, outT);
        mix  = mixT + (mix  - mixT) * mixC;    snap (mix, mixT);
        humG = humT + (humG - humT) * humC;    snap (humG, humT);

        const double l = (double) L[i] * inG;
        const double r = R ? (double) R[i] * inG : l;

        // linked detector: peak of both channels -> one gain for both (stable stereo image)
        const double peak = std::max (std::fabs (l), std::fabs (r));
        const double lvlDb = peak < 1e-6 ? -120.0 : 20.0 * std::log10 (peak);
        const double target = gainReductionDb (lvlDb, ratio, rev);
        const double c = target > gr ? aC : rC;
        gr = target + c * (gr - target);
        if (gr < 1e-9 && target < 1e-9) gr = 0.0;

        const double g = std::exp (-(gr * mix) * kLn10Over20);
        double yl = l * g, yr = r * g;
        if (mix > 0.0)   // FET-style output saturation, crossfaded with comp on/off
        {
            yl = mix * ((std::tanh (satD * (yl + satB)) - satOff) / satD) + (1.0 - mix) * yl;
            yr = mix * ((std::tanh (satD * (yr + satB)) - satOff) / satD) + (1.0 - mix) * yr;
        }
        yl *= outG; yr *= outG;

        if (humG > 0.0)   // optional analogue hum + faint noise; fully skipped when OFF
        {
            humPhase += humW; if (humPhase > 6.283185307179586) humPhase -= 6.283185307179586;
            rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
            const double noise = ((double) rng / 2147483648.0 - 1.0) * 0.25;
            const double h = humG * (std::sin (humPhase) + 0.3 * std::sin (2 * humPhase)
                                     + 0.15 * std::sin (3 * humPhase) + noise);
            yl += h; yr += h;
        }

        const double mi = std::max (l * l, r * r), mo = std::max (yl * yl, yr * yr);
        inMs  += vuA * (mi - inMs);  if (inMs  < 1e-20) inMs  = 0;
        outMs += vuA * (mo - outMs); if (outMs < 1e-20) outMs = 0;

        L[i] = (float) yl;
        if (R) R[i] = (float) yr;
    }
    grDb  = (float) (gr * mix);
    inDb  = (float) (10.0 * std::log10 (std::max (inMs,  1e-12)));
    outDb = (float) (10.0 * std::log10 (std::max (outMs, 1e-12)));
}
}
