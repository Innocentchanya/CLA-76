// CLA-76 Stereo tribute compressor - JUCE-free DSP core (testable standalone).
// Not a model of any specific hardware unit; "revision" voicings are original approximations.
#pragma once
#include <atomic>
#include <cmath>
#include <cstdint>

namespace cla
{
enum class Ratio    : int { R4 = 0, R8, R12, R20, All };
enum class Revision : int { Bluey = 0, Blacky };
enum class HumMode  : int { Off = 0, Hz50, Hz60 };

struct Params
{
    float    inputDb    = 18.0f;    // 0..48   (drive into detector + saturation)
    float    outputDb   = -14.0f;   // -24..24 (default roughly level-matches input 18 dB at ~4 dB GR)
    float    attackMs   = 0.2f;     // 0.02..0.8
    float    releaseMs  = 250.0f;   // 50..1100
    Ratio    ratio      = Ratio::R4;
    Revision revision   = Revision::Bluey;
    HumMode  hum        = HumMode::Off;
    float    humLevelDb = -84.0f;   // fundamental level of optional hum, dBFS
    bool     compEnabled = true;    // false = COMP OFF (input/output gain kept, no GR/saturation)
};

class CompressorDSP
{
public:
    CompressorDSP() = default;
    CompressorDSP (const CompressorDSP& o) { *this = o; }   // copyable (atomics copied by value) - handy for tests
    CompressorDSP& operator= (const CompressorDSP& o)
    {
        fs = o.fs; p = o.p; snapNext = o.snapNext; inG = o.inG; outG = o.outG; mix = o.mix; humG = o.humG; gr = o.gr;
        humPhase = o.humPhase; inMs = o.inMs; outMs = o.outMs; rng = o.rng; smoothC = o.smoothC; mixC = o.mixC;
        humC = o.humC; vuA = o.vuA; aC = o.aC; rC = o.rC;
        grDb = o.grDb.load(); inDb = o.inDb.load(); outDb = o.outDb.load();
        return *this;
    }
    void prepare (double sampleRate);
    void reset();
    void setParams (const Params& p);                       // call once per block (cheap)
    void process (float* const* ch, int numChannels, int numSamples); // in place, 1 or 2 ch, RT-safe

    // Meter values measured by the DSP (thread-safe reads)
    float getGainReductionDb() const { return grDb.load (std::memory_order_relaxed); }  // >= 0
    float getInputLevelDb()    const { return inDb.load (std::memory_order_relaxed); }  // VU-ballistic RMS, dBFS
    float getOutputLevelDb()   const { return outDb.load (std::memory_order_relaxed); }

    // Static gain computer (dB GR for a detector level in dB), exposed for tests.
    static double gainReductionDb (double levelDb, Ratio r, Revision rev);

private:
    double fs = 48000.0;
    Params p {};
    bool   snapNext = true;

    double inG = 1, outG = 1, mix = 1, humG = 0, gr = 0, humPhase = 0, inMs = 0, outMs = 0;
    uint32_t rng = 22222u;
    double smoothC = 0, mixC = 0, humC = 0, vuA = 0, aC = 0, rC = 0;

    std::atomic<float> grDb { 0.f }, inDb { -120.f }, outDb { -120.f };
};

namespace map   // knob <-> value mappings (geometric = perceptually useful)
{
inline float attackMsFromNorm (float n)  { return 0.02f * std::pow (40.0f, n); }
inline float releaseMsFromNorm (float n) { return 50.0f * std::pow (22.0f, n); }
}
}
