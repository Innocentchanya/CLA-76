// Standalone DSP validation (no JUCE needed). Build: see CMakeLists.txt target cla_dsp_tests.
#include "../Source/CompressorDSP.h"
#include <chrono>
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace cla;

static int fails = 0;
#define CHECK(c, ...) do { bool ok_ = (c); if (!ok_) ++fails; printf (ok_ ? "  ok    " : "  FAIL  "); printf (__VA_ARGS__); printf ("\n"); } while (0)

struct Sig { std::vector<float> l, r; };
static Sig makeSig (size_t n) { return { std::vector<float> (n, 0.f), std::vector<float> (n, 0.f) }; }
static void addSine (std::vector<float>& v, double fs, double f, double ampDb, size_t a, size_t b)
{ for (size_t i = a; i < b && i < v.size(); ++i) v[i] = (float) (std::pow (10.0, ampDb / 20) * std::sin (6.283185307179586 * f * (double) (i - a) / fs)); }
static void run (CompressorDSP& d, Sig& s, int block = 256)
{
    for (size_t pos = 0; pos < s.l.size(); pos += (size_t) block)
    {
        int n = (int) std::min<size_t> ((size_t) block, s.l.size() - pos);
        float* ch[2] = { s.l.data() + pos, s.r.data() + pos };
        d.process (ch, 2, n);
    }
}
static CompressorDSP make (double fs, Params p) { CompressorDSP d; d.prepare (fs); d.setParams (p); return d; }
static double rmsDb (const std::vector<float>& v, size_t a, size_t b)
{ double s = 0; for (size_t i = a; i < b; ++i) s += (double) v[i] * v[i]; return 10 * std::log10 (s / (double) (b - a) + 1e-30); }
static double maxAbs (const std::vector<float>& v, size_t a, size_t b)
{ double m = 0; for (size_t i = a; i < b; ++i) m = std::max (m, (double) std::fabs (v[i])); return m; }
static double maxDiff (const std::vector<float>& v, size_t a, size_t b)
{ double m = 0; for (size_t i = a + 1; i < b; ++i) m = std::max (m, (double) std::fabs (v[i] - v[i - 1])); return m; }
static double goertzelDb (const std::vector<float>& v, double fs, double f, size_t a, size_t b)
{
    double re = 0, im = 0; for (size_t i = a; i < b; ++i) { double w = 6.283185307179586 * f * (double) i / fs; re += v[i] * std::cos (w); im += v[i] * std::sin (w); }
    double m = 2.0 * std::sqrt (re * re + im * im) / (double) (b - a); return 20 * std::log10 (m + 1e-30);
}
static bool finite (const std::vector<float>& v) { for (float x : v) if (!std::isfinite (x)) return false; return true; }

int main()
{
    const double fs0 = 48000;

    printf ("[1] Silence / tiny signals\n");
    { Params p; auto d = make (fs0, p); auto s = makeSig (48000); run (d, s);
      CHECK (maxAbs (s.l, 0, s.l.size()) == 0.0 && d.getGainReductionDb() == 0.f, "digital silence -> exact silence, GR = 0");
      std::fill (s.l.begin(), s.l.end(), 1e-30f); std::fill (s.r.begin(), s.r.end(), 1e-38f); run (d, s);
      CHECK (finite (s.l) && finite (s.r) && d.getGainReductionDb() == 0.f, "1e-30 / denormal-range input stays finite, GR = 0"); }

    printf ("[2] Static curve, 1 kHz sine, 4:1, input 18 dB (measured GR vs gain computer)\n");
    { Params p; p.attackMs = 0.02f; p.releaseMs = 50; p.outputDb = 0; double worst = 0;
      for (double lv = -36; lv <= 0; lv += 6)
      { auto d = make (fs0, p); auto s = makeSig (48000); addSine (s.l, fs0, 1000, lv, 0, s.l.size()); s.r = s.l; run (d, s);
        double expect = CompressorDSP::gainReductionDb (lv + 18, Ratio::R4, Revision::Bluey), got = d.getGainReductionDb();
        worst = std::max (worst, std::fabs (expect - got)); printf ("        in %6.1f dBFS  expected GR %5.2f  measured %5.2f\n", lv, expect, got); }
      CHECK (worst < 0.5, "worst deviation %.2f dB (< 0.5)", worst); }

    printf ("[3] Ratios (sine -12 dBFS, input 18 dB)\n");
    { double g[5]; Params p; p.attackMs = 0.02f; p.releaseMs = 50;
      for (int r = 0; r < 5; ++r) { p.ratio = (Ratio) r; auto d = make (fs0, p); auto s = makeSig (48000); addSine (s.l, fs0, 1000, -12, 0, 48000); s.r = s.l; run (d, s); g[r] = d.getGainReductionDb(); }
      printf ("        GR: 4:1 %.1f  8:1 %.1f  12:1 %.1f  20:1 %.1f  ALL %.1f dB\n", g[0], g[1], g[2], g[3], g[4]);
      CHECK (g[0] < g[1] && g[1] < g[2] && g[2] < g[3] && g[3] < g[4], "GR increases monotonically, ALL most aggressive"); }

    printf ("[4] Attack (transient onset peak, input 12 dB, 0 dB out)\n");
    { Params p; p.inputDb = 12; p.outputDb = 0; double pk[2]; float at[2] = { 0.02f, 0.8f };
      for (int k = 0; k < 2; ++k) { p.attackMs = at[k]; auto d = make (fs0, p); auto s = makeSig (24000); addSine (s.l, fs0, 1000, -6, 4800, 9600); s.r = s.l; run (d, s);
        pk[k] = (float) (20 * std::log10 (maxAbs (s.l, 4800, 4800 + 96))); }
      printf ("        first-2ms peak: attack 0.02 ms %.2f dBFS, 0.8 ms %.2f dBFS\n", pk[0], pk[1]);
      CHECK (pk[1] > pk[0] + 0.5, "faster attack catches the transient harder"); }

    printf ("[5] Release (time for GR to fall to 37%% after level drops)\n");
    { Params p; p.attackMs = 0.02f; double t63[2]; float rl[2] = { 50.f, 1100.f };
      for (int k = 0; k < 2; ++k) { p.releaseMs = rl[k]; auto d = make (fs0, p); auto s = makeSig (96000 * 2);
        addSine (s.l, fs0, 1000, -6, 0, 24000); addSine (s.l, fs0, 1000, -70, 24000, s.l.size()); s.r = s.l;
        double gr0 = 0; t63[k] = -1;
        for (size_t pos = 0; pos < s.l.size(); pos += 16) { float* ch[2] = { s.l.data() + pos, s.r.data() + pos }; d.process (ch, 2, 16);
          if (pos == 23984) gr0 = d.getGainReductionDb();
          if (pos > 24000 && t63[k] < 0 && d.getGainReductionDb() <= 0.368 * gr0) t63[k] = (double) (pos - 24000) / fs0 * 1000; } }
      printf ("        release 50 ms -> %.0f ms   release 1100 ms -> %.0f ms\n", t63[0], t63[1]);
      CHECK (t63[0] > 0 && t63[0] < t63[1] * 0.2, "low release recovers much faster than high release");
      CHECK (std::fabs (t63[0] / 50.0 - 1) < 0.35 && std::fabs (t63[1] / 1100.0 - 1) < 0.35, "measured time constants within 35%% of setting"); }

    printf ("[6] Stereo link (L loud 1 kHz, R quiet 1.3 kHz)\n");
    { Params p; Params po = p; po.compEnabled = false; auto on = make (fs0, p), off = make (fs0, po);
      auto a = makeSig (48000); addSine (a.l, fs0, 1000, -12, 0, 48000); addSine (a.r, fs0, 1300, -40, 0, 48000); auto b = a; run (on, a); run (off, b);
      double dR = rmsDb (a.r, 24000, 48000) - rmsDb (b.r, 24000, 48000), gr = on.getGainReductionDb();
      printf ("        quiet channel change %.2f dB, reported GR %.2f dB\n", dR, gr);
      CHECK (gr > 3 && std::fabs (dR + gr) < 0.6, "quiet channel is reduced by the same linked GR (no L/R shift)"); }

    printf ("[7] COMP OFF / output gain / click-free toggle\n");
    { Params p; p.inputDb = 0; p.outputDb = -6; p.compEnabled = false; auto d = make (fs0, p); auto s = makeSig (48000); addSine (s.l, fs0, 1000, -30, 0, 48000); s.r = s.l; run (d, s);
      double diff = rmsDb (s.l, 24000, 48000) - (-30.0 - 3.01);
      CHECK (std::fabs (diff + 6.0) < 0.05, "COMP OFF passes signal with exactly output gain (-6 dB), error %.3f dB", diff + 6.0);
      Params q; q.inputDb = 18; q.outputDb = -14; auto e = make (fs0, q); auto t = makeSig (96000); addSine (t.l, fs0, 1000, -6, 0, 96000); t.r = t.l;
      for (size_t pos = 0; pos < t.l.size(); pos += 256) { if (pos == 48000 - 48000 % 256) { q.compEnabled = false; e.setParams (q); }
        float* ch[2] = { t.l.data() + pos, t.r.data() + pos }; e.process (ch, 2, (int) std::min<size_t> (256, t.l.size() - pos)); }
      double mx = maxAbs (t.l, 0, t.l.size()), md = maxDiff (t.l, 0, t.l.size());
      CHECK (md < 1.5 * mx * 6.283185 * 1000 / fs0, "toggle comp mid-stream: max step %.4f vs sine slope limit %.4f", md, 1.5 * mx * 6.283185 * 1000 / fs0); }

    printf ("[8] Parameter jump during playback (input 0 -> 48 dB)\n");
    { Params p; p.inputDb = 0; p.outputDb = 0; p.compEnabled = false; auto d = make (fs0, p); auto s = makeSig (48000); addSine (s.l, fs0, 440, -30, 0, 48000); s.r = s.l;
      for (size_t pos = 0; pos < s.l.size(); pos += 256) { if (pos == 23808) { p.inputDb = 48; d.setParams (p); } else if (pos == 0) d.setParams (p);
        float* ch[2] = { s.l.data() + pos, s.r.data() + pos }; d.process (ch, 2, (int) std::min<size_t> (256, s.l.size() - pos)); }
      double mx = maxAbs (s.l, 0, s.l.size()), md = maxDiff (s.l, 0, s.l.size());
      CHECK (md < 0.15 * mx, "no zipper/step: max step %.3f of peak %.3f", md, mx); }

    printf ("[9] Sample rates (sine -12 dBFS, 4:1)\n");
    { Params p; p.attackMs = 0.02f; p.releaseMs = 50; double ref = CompressorDSP::gainReductionDb (6, Ratio::R4, Revision::Bluey), worst = 0;
      for (double fs : { 44100.0, 48000.0, 88200.0, 96000.0, 192000.0 })
      { auto d = make (fs, p); auto s = makeSig ((size_t) fs); addSine (s.l, fs, 1000, -12, 0, s.l.size()); s.r = s.l; run (d, s);
        printf ("        %7.0f Hz  GR %.2f dB\n", fs, d.getGainReductionDb()); worst = std::max (worst, std::fabs (d.getGainReductionDb() - ref)); }
      CHECK (worst < 0.5, "GR consistent across sample rates (worst %.2f dB off ideal)", worst); }

    printf ("[10] Analog hum\n");
    { Params p; p.compEnabled = false; p.inputDb = 0; p.outputDb = 0; p.humLevelDb = -60; p.hum = HumMode::Hz50;
      auto d = make (fs0, p); auto s = makeSig (96000); run (d, s);
      double h50 = goertzelDb (s.l, fs0, 50, 48000, 96000), h60 = goertzelDb (s.l, fs0, 60, 48000, 96000);
      printf ("        50 Hz mode: 50 Hz %.1f dBFS, 60 Hz %.1f dBFS\n", h50, h60);
      CHECK (std::fabs (h50 + 60) < 1.0 && h50 > h60 + 20, "50 Hz hum at configured level, clean of 60 Hz");
      p.hum = HumMode::Off; d.setParams (p); auto t = makeSig (48000); run (d, t);
      CHECK (maxAbs (t.l, 24000, 48000) == 0.0, "OFF -> generator fully disabled (exact digital silence)"); }

    printf ("[11] Stability, clipping, CPU (10 s stereo noise, max drive, 48 kHz)\n");
    { Params p; p.inputDb = 48; p.outputDb = 24; p.ratio = Ratio::All; p.hum = HumMode::Hz60; auto d = make (fs0, p);
      auto s = makeSig (480000); unsigned x = 1; for (size_t i = 0; i < s.l.size(); ++i) { x = x * 1664525u + 1013904223u; s.l[i] = ((float) (x >> 8) / 8388608.f - 1.f) * 0.9f; x = x * 1664525u + 1013904223u; s.r[i] = ((float) (x >> 8) / 8388608.f - 1.f) * 0.9f; }
      auto t0 = std::chrono::steady_clock::now(); run (d, s, 512); double sec = std::chrono::duration<double> (std::chrono::steady_clock::now() - t0).count();
      CHECK (finite (s.l) && finite (s.r) && maxAbs (s.l, 0, s.l.size()) < 100.0, "output finite and bounded (peak %.1f)", maxAbs (s.l, 0, s.l.size()));
      printf ("        10 s of audio in %.3f s  (%.0fx realtime, ~%.2f%% of one core)\n", sec, 10.0 / sec, sec / 10.0 * 100); }

    printf ("\n%s (%d failure%s)\n", fails ? "SOME TESTS FAILED" : "ALL TESTS PASSED", fails, fails == 1 ? "" : "s");
    return fails ? 1 : 0;
}
